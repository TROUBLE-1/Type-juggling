<!DOCTYPE html>
<html>
   <title>Type Juggling</title>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   <link rel="stylesheet" href="/htmls/css/home.css">
   <body bgcolor="#afafaf">
      <center>
         <h1 style="font-size:60px;">Type Juggling for updating email id!</h1>
         <h1 style="font-size:30px;">Goal: Do a code review to update email id</h1>
      </center>
      <hr>
      <div style="position: relative; top:10px; align:center; bottom:500px;">
         <center>
            <div id="email">
               <h3 id="emailid" style="font-weight: bold;">Id: rohit@test.local</h3>
            </div>
         </center>
         <div>
            <?php include('challenge/update_chall.php') ?>
         </div>
      </div>
      <center style="padding:10px;"><img src="htmls/image/Capture.PNG" ></center>
   </body>
</html>