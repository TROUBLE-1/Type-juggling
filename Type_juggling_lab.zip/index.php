<?php  require("htmls/home.php"); ?>
<hr>
<center>
   <h2>More Type juggling examples</h2>
   
   <a href="session.php" style="padding:60px;">
   <button>sessions</button>
   </a>      
   <a href="update_email.php" style="padding:60px;">
   <button>update email</button>
   </a>    
</center>