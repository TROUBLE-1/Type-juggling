<?php 

    require("htmls/home.php");
    
    
   ?>