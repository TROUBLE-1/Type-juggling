<?php
$magickey = '0';
if (isset($_REQUEST['password3'])) {
	$key = (($_REQUEST['password3']));
	if ($key == $magickey) {
		echo '<p style="color:red;font-size:30px;">Success</p>';
	} else {
		echo 'failed';
	}
}