<?php
$magickey = '0';
if (isset($_REQUEST['password4'])) {
	$key = (($_REQUEST['password4']));
	if ($key == $magickey) {
		echo '<p style="color:red;font-size:30px;">Success</p>';
	} else {
		echo 'failed';
	}
}